﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bluXpertDesktopClient
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
        private UserProfileServiceReference.UserProfileServiceClient client = null;

		public MainWindow()
		{
			this.InitializeComponent();

            // Insert code required on object creation below this point.
            //connect to the web service
            client = new UserProfileServiceReference.UserProfileServiceClient("BasicHttpBinding_IUserProfileService");
            dtgDisplay.Visibility = Visibility.Hidden;
            grdMainAdd.Visibility = Visibility.Hidden;
        }

		private void btnAddUser_Click(object sender, System.Windows.RoutedEventArgs e)
		{
            dtgDisplay.Visibility = Visibility.Hidden;
            grdMainAdd.Visibility = Visibility.Visible;
		}

		private void btnViewUsers_Click(object sender, System.Windows.RoutedEventArgs e)
		{
            UserProfileServiceReference.UserProfile[] users = client.getAllUsers();

            grdMainAdd.Visibility = Visibility.Hidden;
            dtgDisplay.Visibility = Visibility.Visible;
            dtgDisplay.ItemsSource = users;
		}

		private void btnAddProfile_Click(object sender, System.Windows.RoutedEventArgs e)
		{
            UserProfileServiceReference.UserProfile user_p = new UserProfileServiceReference.UserProfile();
            user_p.name = txtAName.Text;
            user_p.surname = txtASurname.Text;
            user_p.job_title = cmbAJob.Text;
            user_p.bt_id = "0";

            client.addUser(user_p);

            MessageBox.Show("User Added Successfully");
		}
	}
}