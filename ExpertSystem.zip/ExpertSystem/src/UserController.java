/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import java.io.*;
import java.lang.*;
import javax.microedition.io.file.*;
import javax.microedition.io.*;
import javax.microedition.rms.*;
import java.io.DataOutputStream;
import java.io.DataInputStream;

public class UserController {

    //save the user to their record store
    public static boolean SaveUser(User U){
        //try and write the file to the device
        RecordStore rs = null;
        String rsName = U.getName() + U.getSurname();
        try{
            rs = RecordStore.openRecordStore(rsName, true);

            //if the user file already exists, overwrite it
            if (rs.getNumRecords() != 0)
            {
                rs.closeRecordStore();
                DeleteUser(U);
                rs = RecordStore.openRecordStore(rsName, true);
            }

            //save the users details
                rs.addRecord(U.getName().getBytes(), 0, U.getName().getBytes().length);
                rs.addRecord(U.getSurname().getBytes(),0, U.getSurname().getBytes().length);

                //store the job title
                rs.addRecord(U.getJobTitle().getBytes(), 0, U.getJobTitle().getBytes().length);
                
                //store the boolean values
                boolean bool = U.isScanningEnabled();
                String ss = String.valueOf(bool);
                rs.addRecord(ss.getBytes(), 0, ss.getBytes().length);
                bool = U.isAdvertisingEnabled();
                ss = String.valueOf(bool);
                rs.addRecord(ss.getBytes(), 0, ss.getBytes().length);
                
                //get the number of interests and store it in the record
                int n = U.getNumberOfInterests();
                byte[] bn = String.valueOf(n).getBytes();
                rs.addRecord(bn,0,bn.length);
                for (int i = 0; i < U.getNumberOfInterests(); i++)
                {
                    String s = (String)U.getInterest(i);
                    byte[] d = s.getBytes();
                    
                    rs.addRecord(d, 0, d.length);
                }

                //get the number of desired specialties and store it in the record
                n = U.getNumberOfDesiredSpecialties();
                bn = String.valueOf(n).getBytes();
                rs.addRecord(bn,0,bn.length);
                for (int i = 0; i < U.getNumberOfDesiredSpecialties(); i++)
                {
                    String s = (String)U.getDesiredSpecialty(i);
                    byte[] d = s.getBytes();

                    rs.addRecord(d, 0, d.length);
                }

                //get the number of friends and store it in the record
                n = U.getNumberOfFriend();
                bn = String.valueOf(n).getBytes();
                rs.addRecord(bn,0,bn.length);
                if (n > 0){
                    for (int i = 0; i < n; i++)
                    {
                        String s = (String)U.getFriend(i).getName();
                        byte[] d = s.getBytes();

                        rs.addRecord(d, 0, d.length);

                        s = (String)U.getFriend(i).getSurname();
                        d = s.getBytes();

                        rs.addRecord(d, 0, d.length);
                    }
                }

            return true;
        }
        //the writing failed so return false
        catch (RecordStoreException ex){
            System.out.println(ex.getMessage());
            return false;
        }
        catch (SecurityException se){
            System.out.println(se.getMessage());
            return false;
        }
        finally{
            try{
            rs.closeRecordStore();} catch (RecordStoreException e){}
        }
    }

    //load the users information from the record store
    public static User LoadUser(String rsName){
        User U = new User();

        RecordStore rs = null;
        try{
            rs = RecordStore.openRecordStore(rsName, true);

            U.setName(new String(rs.getRecord(1)));
            U.setSurname(new String(rs.getRecord(2)));
            U.setJobTitle(new String(rs.getRecord(3)));

            //load the boolean values
            String b = new String(rs.getRecord(4));
            if (b.equals("true")) U.setScanningEnabled(true);
            else U.setScanningEnabled(false);
            b = new String(rs.getRecord(5));
            if (b.equals("true")) U.setAdvertisingEnabled(true);
            else U.setAdvertisingEnabled(false);

            //get the number of interests
            int n = Integer.parseInt(new String(rs.getRecord(6)));
            if (n > 0){
                //get the interests
                for (int i = 7; i < 7 + n; i++)
                {
                    U.addInterest(new String(rs.getRecord(i)));
                }
            }

            //get the number of desired specialties
            int current_record = 7 + n;
            int m = Integer.parseInt(new String(rs.getRecord(current_record)));
            if (m > 0){
                //get the desired specialties
                current_record++;
                for (int i = current_record; i < current_record + m; i++)
                {
                    U.addDesiredSpecialty(new String(rs.getRecord(i)));
                }
            }

            //get the number of friends
            current_record = 8 + n + m;
            int p = Integer.parseInt(new String(rs.getRecord(current_record)));
            if (p > 0){
                current_record++;
                //get the friends
                int counter = current_record;
                for (int i = current_record; i < current_record + p; i++)
                {
                    String t_name = new String(rs.getRecord(counter));
                    counter ++;
                    String t_surname = new String(rs.getRecord(counter));
                    counter ++;

                    U.addFriend(new Friend(t_name, t_surname));
                }
            }

            //used to test betweenness//U.getFriend(0).addContact(new Contact("Tshepo mas","0",0,false));

            return U; //return the user
        }
        //the writing failed so return false
        catch (RecordStoreException ex){
            System.out.println(ex.getMessage());
            return null;
        }
        catch (SecurityException se){
            System.out.println(se.getMessage());
            return null;
        }
        finally{
            try{
            rs.closeRecordStore();} catch (RecordStoreException e){}
        }
    }

    //updates the last user to use the application
    public static boolean UpdateLastUsersName(String name){
        RecordStore rs = null;
         try{
            rs = RecordStore.openRecordStore("ApplicationStore", true);

            if (rs.getNumRecords() == 0)
                rs.addRecord(name.getBytes(), 0, name.getBytes().length);
            else
                rs.setRecord(1, name.getBytes(), 0, name.getBytes().length);

            return true;
        }
        catch (RecordStoreException ex){
            System.out.println(ex.getMessage());
            return false;
        }
        catch (SecurityException se){
            System.out.println(se.getMessage());
            return false;
        }
        finally{
            try{
            rs.closeRecordStore();} catch (RecordStoreException e){}
        }
    }

    public static String GetLastUsersName()throws Exception{
        RecordStore rs = null;
         try{
            rs = RecordStore.openRecordStore("ApplicationStore", true);
            if (rs.getNumRecords() != 0){
                byte[] data = rs.getRecord(1);
                return new String(data);
            }
            else return null;
        }
        //the writing failed so return false
        catch (RecordStoreException ex){
            System.out.println(ex.getMessage());
            throw new Exception("Cant load last user");
        }
        catch (SecurityException se){
            System.out.println(se.getMessage());
            throw new Exception("Cant load last user");
        }
        finally{
            try{
            rs.closeRecordStore();} catch (RecordStoreException e){ throw new Exception("Cant load last user");}
        }
    }

    public static void DeleteUser(User u)
    {
        String rsName = u.getName() + u.getSurname();
         try{
            RecordStore.deleteRecordStore(rsName);
        }
        catch (RecordStoreException ex){
            System.out.println(ex.getMessage());
        }
        catch (SecurityException se){
            System.out.println(se.getMessage());
        }
    }

    public class UserNotFoundException extends Exception{

        public UserNotFoundException()
        {
            new Exception();
        }
    }
}
