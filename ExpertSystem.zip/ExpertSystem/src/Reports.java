/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import java.util.Vector;

public class Reports {
    private Vector surrounding_devices = null;

    public Reports(){
        surrounding_devices = new Vector();
    }

    public String getSurroundingDevice(int index)
    {
        return (String)surrounding_devices.elementAt(index);
    }

    public void addSurroundingDevice(String name){
        surrounding_devices.addElement(name);
    }

    public void removeSurroundingDevice(int index){
        surrounding_devices.removeElementAt(index);
    }

    public int getSurroundingDeviceIndex(String name){
        for (int i = 0; i < surrounding_devices.size(); i++)
            if (((String)surrounding_devices.elementAt(i)).equals(name))
                return i;

        return -1;
    }

    public int getNumberOfSurroundingDevices() {return surrounding_devices.size();}
}
