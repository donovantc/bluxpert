/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */

import javax.bluetooth.*;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;
import java.io.*;
import java.util.Vector;
import com.sun.lwuit.*;

public class BluetoothManager implements Runnable{
    private boolean isServer = true;
    private User user = null;

    public BluetoothManager(User u){
        user = u;
    }

    public User getUser() {return user;}

    public void run(){
        if (isServer){
            Thread t = new Thread(new BluetoothServer(user));
            t.start();
        }else{
            Thread t = new Thread(new BluetoothClient(user));
            t.start();
        }
    }
}
