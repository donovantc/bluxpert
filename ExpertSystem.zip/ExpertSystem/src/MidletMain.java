/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.midlet.*;
import com.sun.lwuit.*;
import com.sun.lwuit.events.*;
import com.sun.lwuit.layouts.*;
import com.sun.lwuit.animations.*;
import com.sun.lwuit.geom.*;
import com.sun.lwuit.impl.*;
import com.sun.lwuit.list.*;
import com.sun.lwuit.painter.*;
import com.sun.lwuit.plaf.*;
import com.sun.lwuit.spinner.*;
import com.sun.lwuit.table.*;
import com.sun.lwuit.tree.*;
import com.sun.lwuit.util.*;
import javax.microedition.lcdui.Displayable;
import java.io.IOException;
import java.util.Vector;
import javax.microedition.rms.*;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;

/**
 * @author Donovan
 */
public class MidletMain extends MIDlet implements ActionListener {

    //global variables
    //display variables
    Form frmMain = null;
    Form frmCreate = null;
    Form frmEdit = null;
    String s = "BluXpert";
    boolean res_loaded = false;
    Resources resTheme = null;
    Vector Specialties = null;
    Vector interests = null;
    Vector jobs = null;
    String[] job_titles = {"Software Engineer", "Database Administrator", "Financial Manager", "Marketing Manager", "CEO", "Secretary", "HR Manager", "Project Manager", "Other"};
    String[] s_specialties = {"Java", "Finance", "HR", "Marketing", "Sports", "C#", "Law", "Chemical Science", "Web Development", "Entertainment"};
    String[] m_interests = {"Programing", "Soccer", "Rugby", "Cycling", "Golf", "Cricket", "Fishing", "Photography", "Dancing", "Traveling", "History", "Wood Work", "Camping", "Adventures"};
    Command cmdExit = null;
    Command cmdCreate = null;
    //main form commands
    Command cmdNewUser = null;
    Command cmdHide = null;
    Command cmdReports = null;
    String BTStatus = "Stopped";
    
    //Create Profile variables
    TextField txtCreateName = null;
    TextField txtCreateSurname = null;
    ComboBox cmbJobs = null;
    CheckBox chkScanning = null;
    CheckBox chkAdvertising = null;
    Vector vec = null;
    Command cmdDoneInterests = null;
    Command cmdDoneDSpec = null;

    //Specialties variables
    Command cmdBackToCreate = null;

    //add Friend variables
    Command cmdAddFriend = null;
    TextField txtFriendName = null;
    TextField txtFriendSName = null;
    //view friends variables
    Vector vFriends = null;
    Command cmdAddMoreFriends = null;
    //friend details
    TextField txtFName = null;
    TextField txtFSName = null;
    Command cmdEditFriend = null;
    Command cmdBackToFriends = null;
    Command cmdRemoveFriend = null;
    Button btnFriendSave = null;
    int remove_friend_index = 0;

    //Edit Profile Variables
    Command cmdBackToMain = null;
    Command cmdUpdateProfile = null;
    Command cmdBackToEdit = null;
    Vector editVec = null;
    Command cmdAddInterest = null;
    Command cmdAddDSpec = null;
    
    //User variables
    User user = null;
    String last_user_name = null;

    //bluetooth controller variable
    BluetoothManager btManager = null;

    //reporting variable
    Command cmdBackToReportsMain = null;

    //help commands
    Command cmdHelp = null;

    //extra commands
    Command cmdBetween = null;

    public void startApp() {
        Display.init(this);

        //try{RecordStore.deleteRecordStore("ApplicationStore"); }catch (RecordStoreException ex){} //--uncomment to delete the user incase of errors
        
        try{
            last_user_name = UserController.GetLastUsersName();
        }
        catch (Exception e)
        {
            try{RecordStore.deleteRecordStore("ApplicationStore"); }catch (RecordStoreException ex){} //--uncomment to delete the user incase of errors

            Dialog.show("No user!", "No user exists or the file might be corrupted, please reinstall the application", "OK", "OK");
            last_user_name = null;
        }

        //initialise the specialties
        initSpecialties();
        //initialise the interests
        initInterests();
        //initialise the job titles
        initJobTitles();

        //display the main menu
        ShowMainMenu();

        //assign resource theme
        try{
            resTheme = Resources.open("/ThemesRes.res");
            UIManager.getInstance().setThemeProps(resTheme.getTheme("MainTheme"));
            Display.getInstance().getCurrent().refreshTheme();
        }
        catch (IOException ex)
        {
            System.out.println("No Resource Found");
            notifyDestroyed();
        }
        catch (NullPointerException ex)
        {
            System.out.println("Null Pointer Exception");
            notifyDestroyed();
        }
       
        //display the logo
        Image imgLogo = resTheme.getImage("LogoBlu");
        frmMain.addComponent(BorderLayout.NORTH, new Label(imgLogo));
        res_loaded = true;
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }

    private void initSpecialties(){
        Specialties = new Vector();
        for (int i =0; i < s_specialties.length; i++)
            Specialties.addElement(s_specialties[i]);
    }

    private void initInterests(){
        interests = new Vector();
        for (int i =0; i < m_interests.length; i++)
            interests.addElement(m_interests[i]);
    }

    private void initJobTitles(){
        jobs = new Vector();
        for (int i =0; i < job_titles.length; i++)
            jobs.addElement(job_titles[i]);
    }

    private void ShowMainMenu()
    {
        //create the main form
        frmMain = new Form(s);
        frmMain.setLayout(new BorderLayout());
        frmMain.addCommandListener(this);
         
        //create buttons container
        Container buttons = new Container();
        buttons.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        //commamds
        cmdHelp = new Command("Help");
        frmMain.addCommand(cmdHelp);
        cmdExit = new Command("Exit");
        frmMain.addCommand(cmdExit);
        cmdHide = new Command("Hide");
        frmMain.addCommand(cmdHide,1);

        if (last_user_name == null)
        {
            //create profile button
            Button btnCreateProfile = new Button("Create Profile");
            btnCreateProfile.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae)
                {
                    ShowCreateForm();
                }
            });
            buttons.addComponent(btnCreateProfile); //add to the buttons container
        }

        if (last_user_name != null){
            //load the user
            user = UserController.LoadUser(last_user_name);

            //start bluetooth service -----------------------------------------------------------------------------------------------------------------------------------
            try{
                btManager = new BluetoothManager(user);
                Thread t = new Thread(btManager);
                t.start();
                BTStatus = "Running";
            }catch (Exception ex){
                Dialog.show("Error", ex.getMessage(), "OK", "OK");
                BTStatus = "Stopped";
            }
            
            if (user == null)
            {
                Dialog.show("No user!", "No user exists or the file might be corrupted, please reinstall the application", "OK", "OK");
                last_user_name = null;
                ShowMainMenu();
                return;
            }

            //edit profile button
            Button btnEditProfile = new Button("Edit Profile");
            btnEditProfile.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae)
                {
                    ShowProfile();
                }
            });
            buttons.addComponent(btnEditProfile); //add to the buttons container

            //add status
            frmMain.addComponent(BorderLayout.SOUTH, new Label("Bluetooth Status: " + BTStatus));
            //add commands
            cmdReports = new Command("View Reports");
            frmMain.addCommand(cmdReports);
            cmdNewUser = new Command("Create New Profile");
            frmMain.addCommand(cmdNewUser, 1);

            //show the betweenness score of the user
            cmdBetween = new Command("Get Betweenness");
            frmMain.addCommand(cmdBetween);
        }
        
        //add buttons container to form
        frmMain.addComponent(BorderLayout.CENTER, buttons);

        if (res_loaded){
            //display the logo
            Image imgLogo = resTheme.getImage("LogoBlu");
            frmMain.addComponent(BorderLayout.NORTH, new Label(imgLogo));
        }
        //show the form
        frmMain.show();
    }

    public void ShowCreateForm()
    {
        //create a new user
        user = new User();
        
        //create a new form
        frmCreate = new Form(s);
        frmCreate.setLayout(new BorderLayout());
        frmCreate.addCommandListener(this);
        frmCreate.setScrollable(true);

        //Add information label
        frmCreate.addComponent(BorderLayout.NORTH, new Label("Please enter in your details"));

        //container for details
        Container cDetails = new Container();
        cDetails.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        //create label and Textboxes for name
        Label lblName = new Label("Name:");
        txtCreateName = new TextField(10);
        Label lblSurname = new Label("Surname");
        txtCreateSurname = new TextField(10);

        //job title
        Label lblTitle = new Label("Job Title:");
        cmbJobs = new ComboBox();
        //add the job titles to the combo box
        for (int i = 0; i < jobs.size(); i++)
            cmbJobs.addItem((String)jobs.elementAt(i));

        //privacy options
        chkScanning = new CheckBox("Scan for Bluethooth Devices");
        chkAdvertising = new CheckBox("Advertise Bluetooth Device");

        //add buttons
        //define interests button
        Button btnDefineInterests = new Button("Select Interests");
        btnDefineInterests.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
                showInterests();
           }
        });
        //select desired specialty button
        Button btnDesiredSpecialty = new Button("Select Desired Specialties");
        btnDesiredSpecialty.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
                showSpecialties();
           }
        });
        //add friends button
        Button btnAddFriends = new Button("Add Friends");
        btnAddFriends.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                showAddFriendsForm(false);
            }
        });
        //add pitcure button
        Button btnAddPicture = new Button("Add Picture");
        btnAddPicture.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){

           }
        });

        cDetails.addComponent(lblName);
        cDetails.addComponent(txtCreateName);
        cDetails.addComponent(lblSurname);
        cDetails.addComponent(txtCreateSurname);
        cDetails.addComponent(lblTitle);
        cDetails.addComponent(cmbJobs);
        cDetails.addComponent(new Label("Privacy Options"));
        cDetails.addComponent(chkScanning);
        cDetails.addComponent(chkAdvertising);
        cDetails.addComponent(btnDefineInterests);
        cDetails.addComponent(btnDesiredSpecialty);
        cDetails.addComponent(btnAddFriends);
        cDetails.addComponent(btnAddPicture);
        frmCreate.addComponent(BorderLayout.CENTER, cDetails);

        //add exit command
        cmdBackToMain = new Command("Back");
        frmCreate.addCommand(cmdBackToMain);
        //add create command
        cmdCreate = new Command("Create Profile");
        frmCreate.addCommand(cmdCreate);
        //add help command
        cmdHelp = new Command("Help");
        frmCreate.addCommand(cmdHelp);

        Display.getInstance().getCurrent().refreshTheme();
        frmCreate.show();
    }

    //display a list of the interests on screen
    private void showInterests()
    {
        Form frmInterests = new Form(s);
        frmInterests.setLayout(new BorderLayout());
        frmInterests.addCommandListener(this);

        //list the specialties
        Container cInterests = new Container();
        cInterests.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        vec = new Vector();

        for (int i = 0; i < interests.size(); i++)
        {
            vec.addElement(new CheckBox((String)interests.elementAt(i)));
            cInterests.addComponent((CheckBox)vec.elementAt(i));
        }

        frmInterests.addComponent(BorderLayout.NORTH, new Label("Please select your specialties"));
        cmdDoneInterests = new Command("Done");
        frmInterests.addCommand(cmdDoneInterests);

        frmInterests.addComponent(BorderLayout.CENTER, cInterests);

        //add commands
        cmdBackToCreate = new Command("Back");
        frmInterests.addCommand(cmdBackToCreate);

        //show the form
        Display.getInstance().getCurrent().refreshTheme();
        frmInterests.show();
    }

    //display a list of the specialties on screen
    //type = 1 means that the specialties are for the user
    // type != 1 means that the specialties are the ones the user desires
    private void showSpecialties()
    {
        Form frmSpecialties = new Form(s);
        frmSpecialties.setLayout(new BorderLayout());
        frmSpecialties.addCommandListener(this);

        //list the specialties
        Container cSpec = new Container();
        cSpec.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        vec = new Vector();

        for (int i = 0; i < Specialties.size(); i++)
        {
            vec.addElement(new CheckBox((String)Specialties.elementAt(i)));
            cSpec.addComponent((CheckBox)vec.elementAt(i));
        }
      
        frmSpecialties.addComponent(BorderLayout.NORTH, new Label("Please select your desired specialties"));
        cmdDoneDSpec = new Command("Done");
        frmSpecialties.addCommand(cmdDoneDSpec);

        //add containers and components to the form
        frmSpecialties.addComponent(BorderLayout.CENTER, cSpec);

        //add commands
        cmdBackToCreate = new Command("Back");
        frmSpecialties.addCommand(cmdBackToCreate);

        //show the form
        Display.getInstance().getCurrent().refreshTheme();
        frmSpecialties.show();
    }

    private void editInterests(){
         Form frmInterests = new Form(s);
         frmInterests.setLayout(new BorderLayout());
         frmInterests.addCommandListener(this);

        //list the interests
        Container cInts = new Container();
        cInts.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        editVec = new Vector();

        for (int i = 0; i < interests.size(); i++)
        {
            String ss = (String)interests.elementAt(i);
            if (user.getInterestIndex(ss) == -1)
               editVec.addElement(new CheckBox(ss));
        }
        cmdAddInterest = new Command("Add");
        frmInterests.addCommand(cmdAddInterest);

        for (int i = 0; i < editVec.size(); i++)
            cInts.addComponent((CheckBox)editVec.elementAt(i));

        frmInterests.addComponent(BorderLayout.NORTH, new Label("Select Interests"));

        //add containers and components to the form
        frmInterests.addComponent(BorderLayout.CENTER, cInts);

        //add commands
        frmInterests.addCommand(cmdExit);
        cmdBackToEdit = new Command("Back");
        frmInterests.addCommand(cmdBackToEdit);

        //show the form
        Display.getInstance().getCurrent().refreshTheme();
        frmInterests.show();
    }

    private void editSpecialties(){
         Form frmSpecialties = new Form(s);
         frmSpecialties.setLayout(new BorderLayout());
         frmSpecialties.addCommandListener(this);

        //list the specialties
        Container cSpec = new Container();
        cSpec.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        editVec = new Vector();

        for (int i = 0; i < Specialties.size(); i++)
        {
            String ss = (String)Specialties.elementAt(i);
            if (user.getDesiredSpecialtiesIndex(ss) == -1)
                    editVec.addElement(new CheckBox(ss));
        }
        cmdAddDSpec = new Command("Add");
        frmSpecialties.addCommand(cmdAddDSpec);
        
        for (int i = 0; i < editVec.size(); i++)
            cSpec.addComponent((CheckBox)editVec.elementAt(i));

        frmSpecialties.addComponent(BorderLayout.NORTH, new Label("Select desired specialties"));

        //add containers and components to the form
        frmSpecialties.addComponent(BorderLayout.CENTER, cSpec);
        
        //add commands
        frmSpecialties.addCommand(cmdExit);
        cmdBackToEdit = new Command("Back");
        frmSpecialties.addCommand(cmdBackToEdit);

        //show the form
        Display.getInstance().getCurrent().refreshTheme();
        frmSpecialties.show();
    }

    private void showAddFriendsForm(boolean edit){
        //create the form
        Form frmAddFriends = new Form("Add Friend");
        frmAddFriends.setLayout(new BorderLayout());
        frmAddFriends.addCommandListener(this);

        //container for controls
        Container cName = new Container();
        cName.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        //add controls to container
        cmdAddFriend = new Command("Add");
        frmAddFriends.addCommand(cmdAddFriend);

        if (edit){
            cmdBackToFriends = new Command("Back");
            frmAddFriends.addCommand(cmdBackToFriends);
        }
        else
            frmAddFriends.addCommand(cmdBackToCreate);
        cName.addComponent(new Label("Name"));
        txtFriendName = new TextField();
        cName.addComponent(txtFriendName);
        cName.addComponent(new Label("Surname"));
        txtFriendSName = new TextField();
        cName.addComponent(txtFriendSName);

        frmAddFriends.addComponent(BorderLayout.CENTER,cName);

        Display.getInstance().getCurrent().refreshTheme();
        frmAddFriends.show();
    }

    private void ShowProfile()
    {
        //create the edit profile form
        frmEdit = new Form(user.getName() + " " + user.getSurname());
        frmEdit.setLayout(new BorderLayout());
        frmEdit.addCommandListener(this);
        
        //container for details
        Container cDetails = new Container();
        cDetails.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        //job title
        int current_title_index = 0;
        cmbJobs = new ComboBox();
        for (int i = 0; i < jobs.size(); i++)
        {
            String ss = (String)jobs.elementAt(i);
            cmbJobs.addItem(ss);
            if (ss.equals(user.getJobTitle()))
                current_title_index = 0;
        }
        cmbJobs.setSelectedIndex(current_title_index);
        cDetails.addComponent(cmbJobs);

        //privacy settings
        chkScanning = new CheckBox("Scan for Bluethooth Devices");
        if (user.isScanningEnabled()) chkScanning.setSelected(true);
        chkAdvertising = new CheckBox("Advertise Bluetooth Device");
        if (user.isAdvertisingEnabled()) chkAdvertising.setSelected(true);
        Container cPrivacy = new Container();
        cPrivacy.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
        cPrivacy.addComponent(new Label("Privacy Options"));
        cPrivacy.addComponent(chkScanning);
        cPrivacy.addComponent(chkAdvertising);
        cDetails.addComponent(cPrivacy);

        //buttons
        //view the users interests
        final ComboBox cmbInts = new ComboBox();
        cmbInts.addItem(new String("Interests"));
        for (int i = 0; i < user.getNumberOfInterests(); i++)
            cmbInts.addItem(new String(user.getInterest(i)));
        cDetails.addComponent(cmbInts);
        //button to remove specialties
        Button btnSpecialties = new Button("Remove Interest");
        btnSpecialties.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                    int index = cmbInts.getSelectedIndex();
                    if (index == 0) return;
                    user.removeInterest(user.getInterest(index -1));
                    ShowProfile();
            }
        });
        cDetails.addComponent(btnSpecialties);
        //button to add desired specialties
        Button btnAddSpec = new Button("Add Interests");
        btnAddSpec.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               editInterests();
           }
        });
        cDetails.addComponent(btnAddSpec);

        //view the users desired specialties
        final ComboBox cmbDSpecs = new ComboBox();
        cmbDSpecs.addItem(new String("Desired Specialties"));
        for (int i = 0; i < user.getNumberOfDesiredSpecialties(); i++)
            cmbDSpecs.addItem(new String(user.getDesiredSpecialty(i)));
        cDetails.addComponent(cmbDSpecs);
        //button to remove desired specialties
        Button btnDSpecialties = new Button("Remove Desired Specialties");
        btnDSpecialties.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                    //editSpecialties(2);
                    int index = cmbDSpecs.getSelectedIndex();
                    if (index == 0) return;
                    user.removeDesiredSpecialty(user.getDesiredSpecialty(index -1));
                    ShowProfile();
            }
        });
        cDetails.addComponent(btnDSpecialties);
        //button to add desired specialties
        Button btnAddDSpec = new Button("Add Desired Specialties");
        btnAddDSpec.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               editSpecialties();
           }
        });
        cDetails.addComponent(btnAddDSpec);

        //view friends
        Button btnViewFriends = new Button("View Friends");
        btnViewFriends.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
                editFriends();
           }
        });
        cDetails.addComponent(btnViewFriends);

        //add containers to form
        frmEdit.addComponent(BorderLayout.CENTER, cDetails);

        //add command
        cmdBackToMain = new Command("Back");
        frmEdit.addCommand(cmdBackToMain);
        cmdUpdateProfile = new Command("Update Profile");
        cmdHelp = new Command("Help");
        frmEdit.addCommand(cmdHelp);
        frmEdit.addCommand(cmdUpdateProfile);
        frmEdit.addCommand(cmdExit);

        Display.getInstance().getCurrent().refreshTheme();
        frmEdit.show();
    }

    public void editFriends(){
        //view the users friends
        Form frmViewAllFriend = new Form("Friends");
        frmViewAllFriend.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
        frmViewAllFriend.addCommandListener(this);

        //instructions
        frmViewAllFriend.addComponent(new Label("Click on a friend to view details"));

        int nf = user.getNumberOfFriend();
        vFriends = new Vector();
        for (int i = 0; i < nf; i++)
        {
              final int friend_index = i;
              vFriends.addElement(new Button(user.getFriend(i).toString()));
              ((Button)vFriends.elementAt(i)).addActionListener(new ActionListener(){
                  public void actionPerformed(ActionEvent e){
                      ViewFriend(friend_index);
                  }
              });
              frmViewAllFriend.addComponent((Button)vFriends.elementAt(i));
        }


        cmdAddMoreFriends = new Command("Add Friends");
        frmViewAllFriend.addCommand(cmdAddMoreFriends);
        cmdBackToEdit = new Command("Back");
        frmViewAllFriend.addCommand(cmdBackToEdit);

        //display form
        Display.getInstance().getCurrent().refreshTheme();
        frmViewAllFriend.show();
    }

    private void ViewFriend(int index){

        remove_friend_index = index;
        
        Form frmViewFriendDetails = new Form("Friend Details");
        frmViewFriendDetails.setLayout(new BoxLayout(BoxLayout.Y_AXIS));
        frmViewFriendDetails.addCommandListener(this);

        Container cName = new Container();
        cName.setLayout(new BoxLayout(BoxLayout.X_AXIS));
        cName.addComponent(new Label("Name:"));
        txtFName = new TextField();
        txtFName.setText(user.getFriend(index).getName());
        txtFName.setEnabled(false);
        cName.addComponent(txtFName);
        frmViewFriendDetails.addComponent(cName);

        Container cSName = new Container();
        cSName.setLayout(new BoxLayout(BoxLayout.X_AXIS));
        cSName.addComponent(new Label("Surname:"));
        txtFSName = new TextField();
        txtFSName.setText(user.getFriend(index).getSurname());
        txtFSName.setEnabled(false);
        cSName.addComponent(txtFSName);
        frmViewFriendDetails.addComponent(cSName);

       btnFriendSave = new Button("Save");
        final int i_index = index;
        btnFriendSave.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               try{
                    user.getFriend(i_index).setName(txtFName.getText());
                    user.getFriend(i_index).setSurname(txtFSName.getText());

                    btnFriendSave.setVisible(false);
                    txtFName.setEnabled(false);
                    txtFSName.setEnabled(false);
                    
               }catch (Exception ex){
                    Dialog.show("Error", "Please ensure all details are filled in and correct", "OK", "OK");
               }
           }
        });
       btnFriendSave.setVisible(false);
       frmViewFriendDetails.addComponent(btnFriendSave);

       cmdBackToFriends = new Command("Back");
       frmViewFriendDetails.addCommand(cmdBackToFriends);
       cmdEditFriend = new Command("Edit Details");
       frmViewFriendDetails.addCommand(cmdEditFriend);
       cmdRemoveFriend = new Command("Remove Friend");
       frmViewFriendDetails.addCommand(cmdRemoveFriend);
                
       //display form
       Display.getInstance().getCurrent().refreshTheme();
       frmViewFriendDetails.show();
    }


    //show reports about the users recent activities
    public void showReports(){
        Form frmReportMain = new Form(s + " Report");
        frmReportMain.addCommandListener(this);
        frmReportMain.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        //get the contact manager
        ContactManager temp_man = user.getContactManager();

        frmReportMain.addComponent(new Label("Previous Contacts"));
        final ComboBox cmbProximity = new ComboBox();
        final int n_contacts = temp_man.getNumberOfContacts();
        if (n_contacts == 0){
            cmbProximity.addItem(new String("Pervious Contacts"));
        }else{
            for (int i = 0; i < n_contacts; i++){
                cmbProximity.addItem(((Contact)temp_man.getContact(i)).getName());
            }
        }

        frmReportMain.addComponent(cmbProximity);

        Button btnViewUser = new Button("View Details");
        btnViewUser.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                if(n_contacts == 0) return;
                viewIndividualReport(cmbProximity.getSelectedIndex());
            }
        });
        frmReportMain.addComponent(btnViewUser);

        //add the commands
        cmdBackToMain = new Command("Back");
        frmReportMain.addCommand(cmdBackToMain);

        //display the form
        Display.getInstance().getCurrent().refreshTheme();
        frmReportMain.show();

    }

    //the name parameter is just temporary for now and should be replaced with something the contains the all the information that is required
    private void viewIndividualReport(int index){
        Form frmIndividualR = new Form(s + " Report");
        frmIndividualR.setLayout(new BorderLayout());
        frmIndividualR.addCommandListener(this);

        Container cDetails = new Container();
        cDetails.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        Contact c = (Contact)user.getContactManager().getContact(index);

        Container cName = new Container();
        cName.setLayout(new BoxLayout(BoxLayout.X_AXIS));
        cName.addComponent(new Label(c.getName()));
        //load the friend icon
        Image imgFriend = resTheme.getImage("FriendIcon");
        //if this contact is a friend then show the friend icon
        user.compareContactsAndFriends();
        if (c.IsFriend()){
            cName.addComponent(new Label(imgFriend));
        }

        cDetails.addComponent(cName);
        cDetails.addComponent(new Label("Connections with this user: " + c.getTimesConnected()));
        cDetails.addComponent(new Label("Last connection date: "));
        cDetails.addComponent(new Label(c.getLastConnectionDate().toString()));
        //cDetails.addComponent(new Label("Number of friends: 25"));
        //cDetails.addComponent(new Label("Firends in common: 10"));

        frmIndividualR.addComponent(BorderLayout.CENTER, cDetails);

        Container cInfo = new Container();
        cInfo.setLayout(new BoxLayout(BoxLayout.X_AXIS));
        cInfo.addComponent(new Label(imgFriend));
        cInfo.addComponent(new Label(" - indicates user is a friend"));
        frmIndividualR.addComponent(BorderLayout.SOUTH, cInfo);

        //add commands
        cmdBackToReportsMain = new Command("Back");
        frmIndividualR.addCommand(cmdBackToReportsMain);

        //display the form
        Display.getInstance().getCurrent().refreshTheme();
        frmIndividualR.show();
    }

    //show help files
    //section = 1 : Main Screen
    //section = 2 : Create Profile Screen
    //section = 3 : Edit Profile Screnn
    private void showHelp(int section){
        Form frmHelp = new Form(s + " Help");
        frmHelp.addCommandListener(this);

        //create the text area
        TextArea txtHelp = new TextArea();
        txtHelp.setEditable(false);
        txtHelp.setGrowByContent(true);
        txtHelp.setSmoothScrolling(true);
        txtHelp.setIsScrollVisible(true);

        String text = new String();

        if (section == 1){
                text = "Main Screen\n\n" +
                        "Create Profile Button - This button takes you to the create profile screen where you can create a profile for this phone by filling in details\n\n" +
                        "Edit Profile Button - This button takes you to the edit profile screen where you can edit your current details\n\n" +
                        "Hide Command - This command will run the application in the background\n\n" +
                        "Create New Profile Command - This command will allow you to create a new profile for this phone. (Its important to note that should you create a new profile, your old profile will be deleted\n\n" +
                        "View Reports Command - This will take you to a screen where you will be able to view reports created from the Bluetooth connections established\n\n" +
                        "Exit Command - This command will exit the application\n\n" +
                        "The Bluetooth status indicates whether the Bluetooth feature of the application is running or stopped";

                //add back to Main command command
                cmdBackToMain = new Command("Back");
                frmHelp.addCommand(cmdBackToMain);
        }

        if (section == 2){
            text = "Create Profile\n\n" +
                    "Here you need to enter in the required infrormation so that a profile can be created for the phone\n\n" +
                    "Job Title - This refers to your position within the company and you can select your position by selecting from the options in the drop down menu\n\n" +
                    "Privacy Option - If you wish for this device to advertise your Bluetooth ID so that other devices running the application can detect your device then you must check the check box enabling advertising\n" +
                    "If you wish for this device to scan the surrounding area for other Bluetooth devices running the application and make a connection with them then you must check the check box enabling scanning\n\n" +
                    "Select Interests Button - This button will take you to a list of interests where you can select the interests that apply to you. Once you have selected all your interests, select the Done command\n\n" +
                    "Select Desired Specialties - This button will take you to a list of specialties that you would like a potential friend to possess. Once you have selected your desired specialties, select the Dome command\n\n" +
                    "Add Friends Button - This button will take you to a screen where you will be prompted to enter in the name and surname of your friends in the organisaiton who are also using this application\n\n" +
                    "Add picture Button - This button will ask you for the file location of the image you want to use as your profile picture\n\n" +
                    "Create Profile Command - Select this command when you are done entering and selecting all the information pertaining to your profile. This will create your profile (which can be edited at any time)\n\n";

            //add back to Create profile command
            cmdBackToCreate = new Command("Back");
            frmHelp.addCommand(cmdBackToCreate);
        }

        if (section == 3){
            text = "Edit Profile\n\n" +
                    "Here you can edit all the details that you entered in during the create profile phase except for your name and surname\n\n" +
                    "Job Title - This refers to your position within the company and you can select your position by selecting from the options in the drop down menu\n\n" +
                    "Privacy Option - If you wish for this device to advertise your Bluetooth ID so that other devices running the application can detect your device then you must check the check box enabling advertising\n" +
                    "If you wish for this device to scan the surrounding area for other Bluetooth devices running the application and make a connection with them then you must check the check box enabling scanning\n\n" +
                    "Interests Drop Down Menu - This drop down menu displays a list of your interests. If you wish to remove an interest then just select that interests from the drop down menu and click the Remove Interest button\n" +
                    "To add new interests click the Add Interests button and this will take you to a list of interests you can select and add\n\n" +
                    "Desired Specialties Drop Down Menu - This drop down menu displays a list of your desired specialties. If you wish to remove a desired specialty then just select that specialty from the drop down menu and click the Remove Specialty button\n" +
                    "To add new desired specialties click the Add Specialties button and this will take you to a list of desired specialties that you can select and add\n\n" +
                    "View Friends Button - This button will display a list of your friends and by clicking on a friend you can view their information\n\n" +
                    "Update Profile Command - It is important that you select this command after you have completed all your updates otherwise the changes you made will not be saved\n\n";

            //add back to Edit profile command
            cmdBackToEdit = new Command("Back");
            frmHelp.addCommand(cmdBackToEdit);
        }

        txtHelp.setText(text);
        frmHelp.addComponent(txtHelp);

        //display the form
        Display.getInstance().getCurrent().refreshTheme();
        frmHelp.show();
    }

    //overriden method to handle the action events caused by users selecting commands
    public void actionPerformed(ActionEvent e)
    {
        if (e.getCommand() == cmdExit)
            notifyDestroyed();

        //new user command is selected
        if (e.getCommand() == cmdNewUser)
        {
            final Command[] cmds = new Command[2];
                    cmds[0] = new Command("Yes");
                    cmds[1] = new Command("No");
            final Dialog d = new Dialog();
            d.show("WARNING!", "Creating a new user will overwrite the existing user. Are you sure you want to continue?", cmds, Dialog.TYPE_WARNING, null, 1000000000);
            d.addCommandListener(new ActionListener (){
                public void actionPerformed(ActionEvent ae){
                    if (ae.getCommand() == cmds[0])
                        Dialog.show("Hello", "Hello", "Ok", "Ok");
                }
            });
            UserController.DeleteUser(user);
            ShowCreateForm();
        }

        //create command is selected
        if (e.getCommand() == cmdCreate){
            try{
                //user = new User();
                user.setName(txtCreateName.getText());
                user.setSurname(txtCreateSurname.getText());
                user.setJobTitle((String)jobs.elementAt(cmbJobs.getSelectedIndex()));
                user.setScanningEnabled(chkScanning.isSelected());
                user.setAdvertisingEnabled(chkAdvertising.isSelected());

                //save the new user
                if (UserController.SaveUser(user))
                {
                    Dialog.show("User Created", "User has been successfully created", "OK", "Cancel");
                    last_user_name = new String(user.getName() + user.getSurname());
                    UserController.UpdateLastUsersName(last_user_name);
                    ShowMainMenu();
                    //start bluetooth service -----------------------------------------------------------------------------------------------------------------------------------
                    try{
                        btManager = new BluetoothManager(user);
                        Thread t = new Thread(btManager);
                        t.start();
                        BTStatus = "Running";
                    }catch (Exception ex){
                        Dialog.show("Error", ex.getMessage(), "OK", "OK");
                        BTStatus = "Stopped";
                    }
                }
                else Dialog.show("User Creation Unsuccessful", "The new user was not saved", "OK", "Cancel");
            }
            catch (Exception ex)
            {
                System.out.println(ex);
                Dialog.show("Error in Input", "Please ensure the data is entered correctly", "OK", "Cancel");
            }
        }

        //add specialties to profile
        if (e.getCommand() == cmdDoneInterests)
        {
            for (int j = 0; j < vec.size(); j++)
            {
                  CheckBox temp = (CheckBox)vec.elementAt(j);
                  if (temp.isSelected())
                  user.addInterest(temp.getText());
            }
            frmCreate.show();
        }

        //add desired specialties to profile
        if (e.getCommand() == cmdDoneDSpec)
        {
            for (int j = 0; j < vec.size(); j++)
                     {
                         CheckBox temp = (CheckBox)vec.elementAt(j);
                         if (temp.isSelected())
                             user.addDesiredSpecialty(temp.getText());
                     }
                     frmCreate.show();
        }

        //edit interests
        if (e.getCommand() == cmdAddInterest)
        {
            for (int i = 0; i < editVec.size(); i++){
                CheckBox temp = (CheckBox)editVec.elementAt(i);
                if (temp.isSelected())
                    user.addInterest(temp.getText());
            }
            Dialog.show("Add Interests", "Interests have been added, please make sure you update your profile to save these changes", "OK", "OK");
            ShowProfile();
        }

        //edit desired specialties
        if(e.getCommand() == cmdAddDSpec)
        {
            for (int i = 0; i < editVec.size(); i++)
            {
                CheckBox temp = (CheckBox)editVec.elementAt(i);
                if (temp.isSelected())
                    user.addDesiredSpecialty(temp.getText());
            }
            Dialog.show("Add Desired Specialties", "Desired specialties have been added, please make sure you update your profile to save these changes", "OK", "OK");
            ShowProfile();
        }

        if (e.getCommand() == cmdAddFriend)
        {
            try
            {
                String temp_name = txtFriendName.getText();
                String temp_surname = txtFriendSName.getText();

                //add friend to the users friend list
                user.addFriend(new Friend(temp_name, temp_surname));

                //clear the textboxes
                txtFriendName.setText("");
                txtFriendSName.setText("");
                txtFriendName.setFocus(true);
            }
            catch (Exception ex)
            {
                
            }
        }

        //update the profile
        if (e.getCommand() == cmdUpdateProfile){
            user.setJobTitle((String)jobs.elementAt(cmbJobs.getSelectedIndex()));
            user.setScanningEnabled(chkScanning.isSelected());
            user.setAdvertisingEnabled(chkAdvertising.isSelected());
            
            if (UserController.SaveUser(user))
            {
                Dialog.show("Update User", "Your User Profile has been successfully updated.", "OK", "OK");
                //start bluetooth service -----------------------------------------------------------------------------------------------------------------------------------
                /**    try{
                        btManager = new BluetoothManager(user);
                        Thread t = new Thread(btManager);
                        t.start();
                        BTStatus = "Running";
                    }catch (Exception ex){
                        Dialog.show("Error", ex.getMessage(), "OK", "OK");
                        BTStatus = "Stopped";
                    }**/
            }
            else
                Dialog.show("Update User", "Your user profile was not updated, please ensure your details are correct", "OK", "OK");

            //frmMain.show();
            ShowMainMenu();
            
        }

        //adding more friend in edit profile
        if (e.getCommand() == cmdAddMoreFriends)
            showAddFriendsForm(true);

        //viewing a friends details
        if (e.getCommand() == cmdEditFriend){
            txtFName.setEnabled(true);
            txtFSName.setEnabled(true);
            btnFriendSave.setVisible(true);              
        }

        if (e.getCommand() == cmdRemoveFriend){
                user.removeFriend(user.getFriend(remove_friend_index));
                editFriends();
        }

        if (e.getCommand() == cmdBackToFriends){
            editFriends();
        }

        //view reports
        if (e.getCommand() == cmdReports){
            //user = btManager.getUser();
            showReports();
        }

        //Back to create form
        if (e.getCommand() == cmdBackToCreate)
            frmCreate.show();

        //Back to edit
        if (e.getCommand() == cmdBackToEdit)
            ShowProfile();

        //Back to main menu
        if (e.getCommand() == cmdBackToMain){
            //frmMain.show();
            ShowMainMenu();
        }

        //Back to the reports main screen
        if (e.getCommand() == cmdBackToReportsMain){
            showReports();
        }

        if (e.getCommand() == cmdHelp)
        {
            Form frmTemp = Display.getInstance().getCurrent().getComponentForm();
            if (frmTemp == frmMain)
                showHelp(1);
            if (frmTemp == frmCreate)
                showHelp(2);
            if (frmTemp == frmEdit)
                showHelp(3);
        }

        //show the users betweennes
        if (e.getCommand() == cmdBetween){

            String str = new String("");
            for (int i = 0; i < user.getNumberOfFriend(); i++){
                str += "+" + user.getFriend(i).toString() + "\n";
                for (int j = 0; j < user.getFriend(i).getNumberOfContacts(); j++)
                    str += "-" + user.getFriend(i).getContact(j) + "\n";
            }
            Dialog.show("Friends", str, "OK", "OK");
            Dialog.show("Betweenness Score", String.valueOf(user.getBetweenness()), "OK", "OK");
        }

        //hide the application so that it runs in the background
        if (e.getCommand() == cmdHide)
            Display.getInstance().minimizeApplication();
    }
}
