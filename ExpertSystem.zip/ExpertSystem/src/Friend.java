/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import java.util.Vector;

public class Friend {

    //variables
    private String name;
    private String surname;
    private Vector contacts = null;

    public Friend(){name = null; surname = null; contacts = new Vector();}

    public Friend(String n, String sn){
        name = n;
        surname = sn;
        contacts = new Vector();
    }

    public String getName(){return name;}

    public void setName(String s){name = s;}

    public String getSurname(){return surname;}

    public void setSurname(String sn){surname = sn;}

    public void addContact(Contact c){
        contacts.addElement(c);
    }

    public Contact getContact(int index) {return (Contact)contacts.elementAt(index);}

    public void removeContact(int index) {contacts.removeElementAt(index);}

    public int getContactIndex(Contact c){
        for (int i = 0; i < contacts.size(); i++)
            if ((((Contact)contacts.elementAt(i)).getBluetoothID()).equals(c.getBluetoothID()))
                return i;

        return -1;
    }

    public int getNumberOfContacts(){
        return contacts.size();
    }

    public String toString()
    {
        return name + " " + surname;
    }
}
