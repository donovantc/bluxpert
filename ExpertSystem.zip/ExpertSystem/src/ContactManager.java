/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import java.util.Vector;

public class ContactManager {
    Vector connections = null;

    public ContactManager(){
        connections = new Vector();
    }

    public ContactManager(User u, Vector cons){
        connections = cons;
    }

    public void addContact(Contact c){
        connections.addElement(c);
    }

    public Contact getContact(int index) {return (Contact)connections.elementAt(index);}

    public void removeContact(int index) {connections.removeElementAt(index);}

    public int getContactIndex(Contact c){
        for (int i = 0; i < connections.size(); i++)
            if ((((Contact)connections.elementAt(i)).getBluetoothID()).equals(c.getBluetoothID()))
                return i;

        return -1;
    }

    public int getNumberOfContacts(){
        return connections.size();
    }
}
