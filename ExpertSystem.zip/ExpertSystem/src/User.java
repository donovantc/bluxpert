/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import java.util.Vector;
import com.sun.lwuit.*;
import java.io.*;
import java.util.Random;

public class User{

    private String name = null;
    private String surname = null;
    private String job_title = null;
    private Vector interests = null;
    private Image picture = null;
    private boolean scanning_enabled = false;
    private boolean advertising_enabled = false;
    private Vector desired_specialties = null;
    private Vector friend_list = null;
    private ContactManager conMan = null;

    //other variables
    private final int MAX_DESIRED = 5;

    public User()
    {
        name = "";
        surname = "";
        job_title = "";
        interests = new Vector();
        desired_specialties = new Vector();
        friend_list = new Vector();
        conMan = new ContactManager();
    }

    public User(String n, String sn, String jt, Vector intrest, Image img, boolean scan, boolean adv, Vector des, Vector fl, ContactManager cman){
        name = n;
        surname = sn;
        job_title = jt;
        interests = intrest;
        picture = img;
        scanning_enabled = scan;
        advertising_enabled = adv;
        desired_specialties = des;
        friend_list = fl;
        conMan = cman;
    }

    public String getName(){return name;}

    public void setName(String n){name = n;}

    public String getSurname(){return surname;}

    public void setSurname(String sn){surname = sn;}

    public String getJobTitle(){return job_title;}

    public void setJobTitle(String jt){job_title = jt;}

    public boolean isScanningEnabled(){return scanning_enabled;}

    public void setScanningEnabled(boolean b){scanning_enabled = b;}

    public boolean isAdvertisingEnabled(){return advertising_enabled;}

    public void setAdvertisingEnabled(boolean b){advertising_enabled = b;}

    public Image getPicture(){return picture;}

    public void setPicture(Image i){picture = i;}

    //controlling the specialty vector
    public String getInterest(int index){return (String)interests.elementAt(index);}

    public void addInterest(String spec){interests.addElement(spec);}

    public void removeInterest(String spec){interests.removeElement(spec);}

    public int getNumberOfInterests(){return interests.size();}

    public int getInterestIndex(String spec){

        for (int i = 0; i < interests.size();i++){
            if (spec.equals((String)interests.elementAt(i)))
                return i;
        }

        return -1; //if no specialty is found
    }

    //controlling the desired specialty vector
    public String getDesiredSpecialty(int index){return (String)desired_specialties.elementAt(index);}

    public void addDesiredSpecialty(String spec){
        if (desired_specialties.size() < MAX_DESIRED)
            desired_specialties.addElement(spec);
    }

    public void removeDesiredSpecialty(String spec){desired_specialties.removeElement(spec);}

    public int getNumberOfDesiredSpecialties() {return desired_specialties.size();}

    public int getDesiredSpecialtiesIndex(String spec){

        for (int i = 0; i < desired_specialties.size();i++){
            if (spec.equals((String)desired_specialties.elementAt(i)))
                return i;
        }

        return -1; //if no desired specialty is found
    }

    //controlling the friend list vector
    public Friend getFriend(int index){return (Friend)friend_list.elementAt(index);}

    public void addFriend(Friend friend) {friend_list.addElement(friend);}

    public void removeFriend(Friend friend){friend_list.removeElement(friend);}

    public int getNumberOfFriend(){return friend_list.size();}

    public int getFriendIndex(Friend friend){
        for (int i = 0; i < friend_list.size();i++)
            if (friend == (Friend)friend_list.elementAt(i))
                return i;

        return -1; //if no friend is found
    }

    public int getFriendIndex(String name_surname){
        for (int i = 0; i < friend_list.size(); i++)
            if (name_surname.equalsIgnoreCase(((Friend)friend_list.elementAt(i)).toString()))
                return i;

        return -1;
    }

    public ContactManager getContactManager() {return conMan;}

    public void setContactManager(ContactManager cman){conMan = cman;}

    public void compareContactsAndFriends(){
        for (int i = 0; i < friend_list.size(); i++)
        {
            String fName = ((Friend)friend_list.elementAt(i)).toString().toLowerCase();
            for (int j = 0; j < conMan.getNumberOfContacts(); j++){
                if (fName.equals(conMan.getContact(j).getName().toLowerCase()))
                    conMan.getContact(j).setIsFriend(true);
            }
        }
    }

    //calculates the betweenness centrality of the user
    public double getBetweenness(){
        try{
            //check that the user has friends first
            int n = getNumberOfFriend();
            if (n == 0) return 0;

            //the matrix A used for the calculation
            int A[][] = new int[n][n];

            //initialise matrix A to zeros
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    A[i][j] = 0;

            
            //the columns and the rows of the matrix consist of the user and his/her friends
            for (int i = 0; i < n; i++){
                //the first col will be 1s for the friends of the user because he/she obviously knows them
                if (i > 0)
                    A[i][0] = 1;
                for (int j = 0; j < n; j++){
                    //the first row will be 1s for the friends of the user
                    if (j > 0)
                        A[0][j] = 1;
                    //the friend knows himself
                    if ( i != j){
                        Friend f = getFriend(j);
                        A[i][j] = checkFriend(getFriend(i), f);
                    }
                }
            }

            //multiply A with A to get A squared
            int ASquared[][] = MatrixOperations.MatrixMultiplication(A,A,n,n);

            //matrix with all entries = 1
            int OneMatrix[][] = new int[n][n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    OneMatrix[i][j] = 1;

            //perform matrix substitution [1-A]ij
            int resultingMatrix[][] = MatrixOperations.MatrixSubstitution(OneMatrix,A,n,n);

            //multiply the two resulting matrices obtained above A squared * [1-A]ij
            int finalResult[][] = MatrixOperations.MatrixMultiplication(ASquared, resultingMatrix, n, n);

            //since the matrix is symmetric, consider the non zero entries above the diagonal
            Vector nonZeroEntries = new Vector();
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++){
                    if ((j > i) && (finalResult[i][j] != 0))
                        nonZeroEntries.addElement(new Integer(finalResult[i][j]));
                }

            //sum the reciprocals of all the values in the nonZeroEntries vector
            double betweennes = 0;
            for (int i = 0; i < nonZeroEntries.size(); i++)
                betweennes += (1.0/((Integer)nonZeroEntries.elementAt(i)).intValue());

            return betweennes;
        }catch (Exception ex)
        {
            Dialog.show("ERROR","Betweenness error: " + ex.getMessage(),"OK","OK");
            return 0;
        }
    }

    private int checkFriend(Friend rowF, Friend colF){
        String fName = rowF.toString();

        int no_contacts = colF.getNumberOfContacts();

        if (no_contacts == 0) return 0;

        for (int i = 0; i < no_contacts; i++)
            if (fName.equalsIgnoreCase(colF.getContact(i).getName()))
                return 1;

        return 0;
    }
}
