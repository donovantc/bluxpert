/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import javax.bluetooth.*;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;
import java.io.*;
import java.util.Vector;
import com.sun.lwuit.*;
import java.util.Date;


public class BluetoothServer implements Runnable{
    //variables
    private LocalDevice local = null;
    private RemoteDevice remote = null;
    private DiscoveryAgent discovery = null;
    private static final UUID BT_UUID = new UUID(0x0003);
    private String URL = "btspp://localhost:" + BT_UUID.toString() + ";name=bluxpert;authorize=false;authenticate=false;encrypt=false";
    private StreamConnectionNotifier notifier;
    private ServiceRecord record = null;
    private StreamConnection conn = null;
    private Vector remoteDevices = null;
    private Reports reports = null;
    private ContactManager conMan = null;

    //the user
    User user = null;

    public BluetoothServer(User u){
        user = u;
        conMan = user.getContactManager();
        remoteDevices = new Vector();
        reports = new Reports();

        //just a test to generete test report data
        generateTestReportData();
    }

    public Reports getReports(){return reports;}

    //initialise the bluetooth stack
    private void BluetoothInit(){
        try{
            local = LocalDevice.getLocalDevice();
            discovery = local.getDiscoveryAgent();

            //if (user.isAdvertisingEnabled())
            local.setDiscoverable(DiscoveryAgent.GIAC);
            //else local.setDiscoverable(DiscoveryAgent.NOT_DISCOVERABLE);

            //the stream notifier
            notifier = (StreamConnectionNotifier)Connector.open(URL);

            //record = local.getRecord(notifier);
            //DataElement base = new DataElement(DataElement.DATSEQ);
            //record.setAttributeValue(ATTRIBUTE_ID, base);
            //String sss = record.getConnectionURL(ServiceRecord.NOAUTHENTICATE_NOENCRYPT, true);
            //Dialog.show("INFO", sss, "OK", "OK");

            while (true){
                conn = (StreamConnection)notifier.acceptAndOpen();

                //get the remote device
                //remote = RemoteDevice.getRemoteDevice(conn);
                //Dialog.show("Device Name", remote.getFriendlyName(true), "OK", "OK");
                //Dialog.show("INFO", "Gets here", "OK", "OK");
                //while(true){
                    try{
                        InputStream is = conn.openInputStream();
                        OutputStream os = conn.openOutputStream();

                        //send the users name to the client
                        String s = user.getName() + " " + user.getSurname() + "%";
                        byte[] b = s.getBytes();
                        os.write(b);
                        os.flush();

                        //send the users betweenness value
                        s = String.valueOf(user.getBetweenness());
                        b = s.getBytes();
                        os.write(b);
                        os.flush();

                        //get the name of the user we connecting to
                        byte[] buf = new byte[256];
                        is.read(buf);
                        String name = new String(buf);

                        //get the Bluetooth ID
                        buf = new byte[12];
                        is.read(buf);
                        String id = new String(buf);

                        
                        //get betweenness value
                        buf = new byte[8];
                        is.read(buf);
                        double betweenness = Double.parseDouble(new String(buf));

                        //create new connection to add to the contact manager
                        Contact c = new Contact();
                        c.setName(name.substring(0, name.indexOf("%")));
                        c.setBluetoothID(id);
                        //get the index of this connection if it exists
                        int index = user.getContactManager().getContactIndex(c);

                        if (index == -1)
                        {
                            //add the user to the contact manager
                            user.getContactManager().addContact(c);
                            Dialog.show("Connection", "Connection established with " + c.getName(), "OK", "OK");
                            user.compareContactsAndFriends();

                            //get the current contact if they are friends
                            c = user.getContactManager().getContact(user.getContactManager().getContactIndex(c));
                            if (c.IsFriend())
                            {
                                //ask the client to send all his friends
                                String request = "SEND_FRIENDS%";
                                b = request.getBytes();
                                os.write(b);
                                os.flush();

                                //recieve the friends and store them
                                //the number of contacts
                                buf = new byte[10];
                                is.read(buf);
                                String t = new String(buf);
                                int msgLength = Integer.parseInt(t.substring(0, t.indexOf("%")));

                                Dialog.show("The Msg Length", String.valueOf(msgLength), "OK", "OK");

                                
                               buf = new byte[msgLength];
                               is.read(buf);
                               s = new String(buf);
                               Dialog.show("Complete string", s, "OK", "OK");

                               int contact_index = 0;

                               while (s.length() > 1)
                               {
                                   int temp_index = s.indexOf("%"); //the index of %
                                   String temp = s.substring(0,temp_index);
                                   //display the new contacts name
                                   Dialog.show("Contact Added", temp, "OK", "OK");
                                   //create the contact and add it to the friends contacts
                                   Contact con = new Contact();
                                   con.setName(temp);
                                   user.getFriend(user.getFriendIndex(c.getName())).addContact(con);
                                   //user.getFriend(user.getFriendIndex(c.getName())).getContact(contact_index).setName(temp);

                                   contact_index++;

                                   s = s.substring(temp_index + 1);
                               }

                               //check if the client has requested the users friends
                                buf = new byte[50];
                                is.read(buf);
                                String st = new String(buf);
                                if (st.substring(0, st.indexOf("%")).equalsIgnoreCase("SEND_FRIENDS")){
                                    Dialog.show("Message", "Client wants friends", "OK", "OK");

                                    int no_friends = user.getNumberOfFriend();

                                    s = new String("");
                                    for (int i = 0; i < user.getNumberOfFriend(); i++)
                                        s += user.getFriend(i).toString() + "%";

                                    Dialog.show("Friend list", s, "OK", "OK");
                                    int length = s.getBytes().length;

                                    String msglength = String.valueOf(length) + "%";
                                    os.write(msglength.getBytes());
                                    os.flush();

                                    os.write(s.getBytes());
                                    os.flush();
                                }
                                else{
                                    Dialog.show("Message", "Client Does Not want friends", "OK","OK");
                                }

                            }
                            else{
                                String request = "NO_FRIENDS%";
                                os.write(request.getBytes());
                                os.flush();
                            }

                        }
                        else{
                            c = user.getContactManager().getContact(user.getContactManager().getContactIndex(c));
                        }

                        //update the contacts information
                        c.setLastConnectionDate(new Date());
                        c.incTimesConnected();

                       

                        //Close the IO Connections
                        is.close();
                        os.close();
                        conn.close();

                    }catch (IOException ex){
                        Dialog.show("Error", ex.getMessage(), "OK", "OK");
                    }
            }
         }
         catch(BluetoothStateException ex){
              System.out.println(ex);
              Dialog.show("Error", ex.toString(), "OK", "OK");
         }
         catch(IOException ex){
              System.out.println(ex);
              Dialog.show("Error", ex.toString(), "OK", "OK");
         }
    }

    /**
    //overriden method
    public void deviceDiscovered(RemoteDevice remoteDevice, DeviceClass cod){
        try{
                Dialog.show("Device Found", "found: " + remoteDevice.getFriendlyName(true), "OK", "OK");
        } catch(Exception e){
                Dialog.show("Device Found", "found: " + remoteDevice.getBluetoothAddress(), "OK", "OK");
        } finally{
		   remoteDevices.addElement(remoteDevice);
            

            Dialog.show("Info", "Gets Here", "OK", "OK");
            
            try{
                //get input and output stream
                InputStream is = conn.openInputStream();
                OutputStream os = conn.openOutputStream();

                //test the connection
                byte[] buffer = new byte[100];
                String msg = "Hello Client";

                os.write(msg.getBytes());
                is.read(buffer);
                Dialog.show("Client message", new String(buffer), "OK", "OK");

                conn.close();
                is.close();
                os.close();

            }catch (IOException ex){
                System.out.println(ex);
                Dialog.show("Error!", ex.toString(), "OK", "OK");
            }
            catch (Exception ex){
                Dialog.show("Error!", ex.toString(), "OK", "OK");
            }
	}
    }

    //overriden method
    public void inquiryCompleted(int diskType){

    }

    //overrriden method
    public void servicesDiscovered(int transID, ServiceRecord[] servRecord){
            
    }
    
    //overriden method
    public void serviceSearchCompleted(int transID, int respCode){
        
    }**/

    //overriden method
    public void run(){
        BluetoothInit();
    }

    public Vector GetContacts(){
        return remoteDevices;
    }

    public String getBTAddress() {return local.getBluetoothAddress();}

    //just a test to test the reporting by using static data
    public void generateTestReportData(){
        String[] s = {"Tim Hope", "Lance Issacs", "Freddie James", "Calvin Williams", "Mike Thompsons"};
        for (int i = 0; i < s.length; i++)
            reports.addSurroundingDevice(s[i]);
    }

}
