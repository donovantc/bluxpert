/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import javax.bluetooth.*;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;
import java.io.*;
import java.util.Vector;
import com.sun.lwuit.*;


public class BluetoothController implements Runnable{
    //variables
    private LocalDevice local = null;
    private RemoteDevice remote = null;
    private DiscoveryAgent discovery = null;
    private static final UUID BT_UUID = new UUID(0x0003);
    private String URL = "btspp://localhost:" + BT_UUID.toString() + ";name=bluxpert;authorize=false";
    private StreamConnectionNotifier notifier;
    private ServiceRecord record = null;
    private StreamConnection conn = null;
    private Vector remoteDevices = null;
    private Reports reports = null;

    //the user
    User user = null;

    public BluetoothController(User u){
        user = u;
        remoteDevices = new Vector();
        reports = new Reports();

        //just a test to generete test report data
        generateTestReportData();
    }

    public Reports getReports(){return reports;}

    //initialise the bluetooth stack
    private void BluetoothInit(){
        try{
            local = LocalDevice.getLocalDevice();
            discovery = local.getDiscoveryAgent();

            //if (user.isAdvertisingEnabled())
            local.setDiscoverable(DiscoveryAgent.GIAC);
            //else local.setDiscoverable(DiscoveryAgent.NOT_DISCOVERABLE);

            //the stream notifier
            notifier = (StreamConnectionNotifier)Connector.open(URL);

            //record = local.getRecord(notifier);
            //DataElement base = new DataElement(DataElement.DATSEQ);
            //record.setAttributeValue(ATTRIBUTE_ID, base);
            //String s = record.getConnectionURL(ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false);
            //Dialog.show("INFO", s, "OK", "OK");

            conn = (StreamConnection)notifier.acceptAndOpen();

            //get the remote device
            remote = RemoteDevice.getRemoteDevice(conn);
            Dialog.show("Device Name", remote.getFriendlyName(true), "OK", "OK");
            
            while(true){
                try{
                    InputStream is = conn.openInputStream();
                    OutputStream os = conn.openOutputStream();

                    os.write(new String("Hello").getBytes());
                    os.flush();
                    Dialog.show("INFO", "Gets here", "OK", "OK");
                    
                    byte[] buf = new byte[100];
                    is.read(buf);
                    String msg = new String(buf);

                    Dialog.show("Message From Client", msg, "OK", "OK");

                    Dialog.show("INFO", "Gets here", "OK", "OK");
                    is.close();
                    os.close();

                }catch (IOException ex){
                    Dialog.show("Error", ex.getMessage(), "OK", "OK");
                }
            }
        }
        catch(BluetoothStateException ex){
            System.out.println(ex);
            Dialog.show("Error", ex.toString(), "OK", "OK");
        }
        catch(IOException ex){
            System.out.println(ex);
            Dialog.show("Error", ex.toString(), "OK", "OK");
        }
    }

    /**
    //overriden method
    public void deviceDiscovered(RemoteDevice remoteDevice, DeviceClass cod){
        try{
                Dialog.show("Device Found", "found: " + remoteDevice.getFriendlyName(true), "OK", "OK");
        } catch(Exception e){
                Dialog.show("Device Found", "found: " + remoteDevice.getBluetoothAddress(), "OK", "OK");
        } finally{
		   remoteDevices.addElement(remoteDevice);
            

            Dialog.show("Info", "Gets Here", "OK", "OK");
            
            try{
                //get input and output stream
                InputStream is = conn.openInputStream();
                OutputStream os = conn.openOutputStream();

                //test the connection
                byte[] buffer = new byte[100];
                String msg = "Hello Client";

                os.write(msg.getBytes());
                is.read(buffer);
                Dialog.show("Client message", new String(buffer), "OK", "OK");

                conn.close();
                is.close();
                os.close();

            }catch (IOException ex){
                System.out.println(ex);
                Dialog.show("Error!", ex.toString(), "OK", "OK");
            }
            catch (Exception ex){
                Dialog.show("Error!", ex.toString(), "OK", "OK");
            }
	}
    }

    //overriden method
    public void inquiryCompleted(int diskType){

    }

    //overrriden method
    public void servicesDiscovered(int transID, ServiceRecord[] servRecord){
            
    }
    
    //overriden method
    public void serviceSearchCompleted(int transID, int respCode){
        
    }**/

    //overriden method
    public void run(){
        BluetoothInit();
    }

    public Vector GetContacts(){
        return remoteDevices;
    }

    public String getBTAddress() {return local.getBluetoothAddress();}

    //just a test to test the reporting by using static data
    public void generateTestReportData(){
        String[] s = {"Tim Hope", "Lance Issacs", "Freddie James", "Calvin Williams", "Mike Thompsons"};
        for (int i = 0; i < s.length; i++)
            reports.addSurroundingDevice(s[i]);
    }

}
