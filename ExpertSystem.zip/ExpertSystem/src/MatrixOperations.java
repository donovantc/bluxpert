/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
public class MatrixOperations {

        //perform a matrix substitution with 2 matrix of the same size
        public static int[][] MatrixSubstitution(int[][] A, int[][] B, int rows, int cols){
            int result[][] = new int[rows][cols];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    result[i][j] = A[i][j] - B[i][j];

            return result;
        }

        //perform a matrix mulitplication operation with a 2 matrices of the same size
        public static int[][] MatrixMultiplication(int[][] A, int[][] B, int rows, int cols){
            int result[][] = new int[rows][cols];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++){
                    result[i][j]=0;
                    for(int k = 0; k < rows; k++)
                        result[i][j] = result[i][j] + A[i][k] * B[k][j];
                    }

            return result;
        }
}
