/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import java.util.Date;

public class Contact {
    private String name = null;
    private String bt_id = "";
    private int times_connected = 0;
    private boolean friend = false;
    private Date last_con_date = null;

    public Contact(){
        name = "";
        bt_id = "";
        times_connected = 0;
        friend = false;
    }

    public Contact(String n, String id, int no, boolean b){
        name = n;
        bt_id = id;
        times_connected = no;
        friend = b;
    }

    public void setName(String n){name = n;}

    public String getName(){return name;}

    public void setBluetoothID(String id){bt_id = id;}

    public String getBluetoothID(){return bt_id;}

    public void setTimesConnected(int n){times_connected = n;}

    public void incTimesConnected(){times_connected++;}

    public int getTimesConnected(){return times_connected;}

    public void setIsFriend(boolean b){friend = b;}

    public boolean IsFriend(){ return friend;}

    public Date getLastConnectionDate() {return last_con_date;}

    public void setLastConnectionDate(Date date) {last_con_date = date;}
}
