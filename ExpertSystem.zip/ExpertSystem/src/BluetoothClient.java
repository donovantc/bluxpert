/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Donovan
 */
import javax.bluetooth.*;
import javax.obex.*;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;
import java.io.*;
import java.util.Vector;
import com.sun.lwuit.*;
import java.util.Date;

public class BluetoothClient implements Runnable, DiscoveryListener {
    private User user = null;
    private ContactManager conMan = null;
    private StreamConnectionNotifier notifier;
    private ServiceRecord[] record = null;
    private StreamConnection conn = null;
    private String connURL = null;
    private RemoteDevice remote_Device = null;
    private LocalDevice local = null;
    private DiscoveryAgent discovery = null;
    private UUID uuid = new UUID(0x0003);
    private static final int ATTRIBUTE_ID = 0x6789;
    private String url = "btspp://localhost:" + uuid.toString() + ";name=bluxpert;authorize=false;authenticate=false;encrypt=false";
    private final static Object lock = new Object();
    private Vector remote_devices = new Vector();

    public BluetoothClient(User u){
        user = u;
        conMan = user.getContactManager();
    }

    //initialise the bluetooth stack
    private void BluetoothInit(){
        try{
            local = LocalDevice.getLocalDevice();
            discovery = local.getDiscoveryAgent();

            //if (user.isAdvertisingEnabled())
            local.setDiscoverable(DiscoveryAgent.GIAC);
            //else local.setDiscoverable(DiscoveryAgent.NOT_DISCOVERABLE);

           //while (true){
               try{
                //start the inquiry to discover devices
                discovery.startInquiry(DiscoveryAgent.GIAC, this);

                //wait while devices are discovered
                try {
                    synchronized(lock){
                    lock.wait();
                    }
                }
                catch (InterruptedException e) {
                    Dialog.show("Exception", e.getMessage(), "OK", "OK");
                }

                //display remote devices found
                /**String allDevs = new String("");
                for (int i = 0 ; i < remote_devices.size(); i++)
                    allDevs += ((RemoteDevice)remote_devices.elementAt(i)).getFriendlyName(true) + ";";
                Dialog.show("Remote Devices", allDevs, "OK", "OK");**/

                //search for services
                discovery.searchServices(null,new UUID[] { uuid }, remote_Device, this);
                /**connURL = discovery.selectService(uuid, ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false);
                if (connURL == null){
                    Dialog.show("Service is null", "connURL null", "OK", "OK");
                    break;
                }**/

                //wait while devices searches for services
                try {
                    synchronized(lock){
                    lock.wait();
                    }
                }
                catch (InterruptedException e) {
                    Dialog.show("Exception", e.getMessage(), "OK", "OK");
                }

                if (connURL == null){
                    Dialog.show("Service Error", "Service Doesnt exists", "OK", "OK");
                    //break;--------------------------------------------------------------------changed coz of while
                }

                conn = (StreamConnection)Connector.open(connURL);
                //Dialog.show("INFO", "Connection established with " + remote_Device.getFriendlyName(true), "OK", "OK");
                if (conn != null)
                {
                    InputStream is = conn.openInputStream();
                    OutputStream os = conn.openOutputStream();

                    //get the name of the user connected to
                    byte[] buf = new byte[256];
                    is.read(buf);
                    String name = new String(buf);

                    //get betweenness value
                    buf = new byte[8];
                    is.read(buf);
                    double betweenness = Double.parseDouble(new String(buf));

                    //get the bluetooth address
                    String id = remote_Device.getBluetoothAddress();

                     //send the users name to the server
                    //% is used as a flag to mark the end of the name
                    String s = user.getName() + " " + user.getSurname() + "%";
                    os.write(s.getBytes());
                    os.flush();

                    //send the Bluetooth ID
                    s = local.getBluetoothAddress();
                    os.write(s.getBytes());
                    os.flush();

                    
                    //send the users betweenness value
                    s = String.valueOf(user.getBetweenness());
                    os.write(s.getBytes());
                    os.flush();
                    
                     //create new connection to add to the contact manager
                    Contact c = new Contact();
                    c.setName(name.substring(0, name.indexOf("%")));
                    c.setBluetoothID(id);
                    //get the index of this connection if it exists
                    int index = user.getContactManager().getContactIndex(c);

                    //update the contac manager with the contact
                    if (index == -1)
                    {
                       //add the user to the contact manager
                       user.getContactManager().addContact(c);
                       Dialog.show("Connection", "Connection established with " + c.getName(), "OK", "OK");
                       user.compareContactsAndFriends();
                    }
                   
                   //get the current contact
                   c = user.getContactManager().getContact(user.getContactManager().getContactIndex(c));
                   
                   //update the contacts information
                   c.setLastConnectionDate(new Date());
                   c.incTimesConnected();
                    
                    //check if the client has requested the users friends
                    buf = new byte[50];
                    is.read(buf);
                    String st = new String(buf);
                    if (st.substring(0, st.indexOf("%")).equalsIgnoreCase("SEND_FRIENDS")){
                        Dialog.show("Message", "Server wants friends", "OK", "OK");
                        
                        int no_friends = user.getNumberOfFriend();

                        s = new String("");
                        for (int i = 0; i < user.getNumberOfFriend(); i++)
                            s += user.getFriend(i).toString() + "%";

                        Dialog.show("Friend list", s, "OK", "OK");
                        int length = s.getBytes().length;

                        String msglength = String.valueOf(length) + "%";
                        os.write(msglength.getBytes());
                        os.flush();

                        os.write(s.getBytes());
                        os.flush();
                    }
                    else{
                        Dialog.show("Message", "Server Does Not want friends", "OK","OK");
                    }

                    //check if the current contact is a friends
                    if (c.IsFriend())
                    {
                        //ask the client to send all his friends
                        String request = "SEND_FRIENDS%";
                        buf = request.getBytes();
                        os.write(buf);
                        os.flush();

                        //recieve the friends and store them
                        //the number of contacts
                        buf = new byte[10];
                        is.read(buf);
                        String t = new String(buf);
                        int msgLength = Integer.parseInt(t.substring(0, t.indexOf("%")));

                        Dialog.show("The Msg Length", String.valueOf(msgLength), "OK", "OK");

                        buf = new byte[msgLength];
                        is.read(buf);
                        s = new String(buf);
                        Dialog.show("Complete string", s, "OK", "OK");

                        while (s.length() > 1)
                        {
                             int temp_index = s.indexOf("%"); //the index of %
                             String temp = s.substring(0,temp_index);
                             //display the new contacts name
                             Dialog.show("Contact Added", temp, "OK", "OK");
                             //create the contact and add it to the friends contacts
                             Contact tempCon = new Contact();
                             tempCon.setName(temp);
                             user.getFriend(user.getFriendIndex(c.getName())).addContact(tempCon);
                             s = s.substring(temp_index + 1);
                        }
                    }
                    else{
                        String request = "NO_FRIENDS%";
                        os.write(request.getBytes());
                        os.flush();
                    }   
                       
                                       
                    //close the IO connections
                    os.close();
                    is.close();
                    conn.close();
                    conn = null;
                }

            }//end of try in while loop
            catch(BluetoothStateException ex){
                //if (ex.getMessage().equals("Busy")) break; ------------------changed coz of while
                Dialog.show("Error", ex.getMessage(), "OK", "OK");
            }
            catch(IOException ex){
                Dialog.show("Error", ex.getMessage(), "OK", "OK");
            }
            catch (Exception ex){
                Dialog.show("Error", ex.getMessage(), "OK", "OK");
            }
            //}//end of while loop
        }
        catch(BluetoothStateException ex){
                Dialog.show("Error", ex.getMessage(), "OK", "OK");
            }
            catch(IOException ex){
                Dialog.show("Error", ex.getMessage(), "OK", "OK");
            }
            catch (Exception ex){
                Dialog.show("Error", ex.getMessage(), "OK", "OK");
            }
    }

    //overriden method
    public void deviceDiscovered(RemoteDevice remoteDevice, DeviceClass cod){
        //try{
        //        Dialog.show("Device Found", "found: " + remoteDevice.getFriendlyName(true), "OK", "OK");
        //} catch(Exception e){
        //        Dialog.show("Device Found", "found: " + remoteDevice.getBluetoothAddress(), "OK", "OK");
        //} finally{
           
	//}
       // remote_devices.addElement(remoteDevice);
        remote_Device = remoteDevice;
        //String s = remote.getBluetoothAddress();
        //Dialog.show("Info", s, "OK", "OK");
        //discovery.cancelInquiry(this);
    }

    //overriden method
    public void inquiryCompleted(int diskType){
        synchronized(lock){
            lock.notify();
        }
    }

    //overrriden method
    public void servicesDiscovered(int transID, ServiceRecord[] servRecord){
        for (int i = 0; i < servRecord.length; i++){
            connURL = servRecord[i].getConnectionURL(ServiceRecord.NOAUTHENTICATE_NOENCRYPT,false);

            if(connURL.indexOf(":3") != -1 || connURL.indexOf(":12") != -1)
            {
                //Dialog.show("INFO", connURL, "OK", "OK");
                synchronized(lock){
                    lock.notify();
                }
            break;
           }
        }
        
    }

    //overriden method
    public void serviceSearchCompleted(int transID, int respCode){
        synchronized(lock){
            lock.notify();
        }
    }

    public void run(){
        BluetoothInit();
    }
}
