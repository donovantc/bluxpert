﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace UserProfileService
{
    [DataContract]
    public class Friend
    {
        [DataMember]
        UserProfile profile;
        [DataMember]
        int times_connected;
        [DataMember]
        DateTime last_connection;
        [DataMember]
        float trust_level;

        public Friend()
        {
            profile = new UserProfile();
            times_connected = 0;
            last_connection = new DateTime();
            trust_level = 0;
        }

        public UserProfile Profile
        {
            get { return profile; }
            set { profile = value; }
        }

        public int TimesConnected
        {
            get { return times_connected; }
            set { times_connected = value; }
        }

        public DateTime LastConnection
        {
            get { return last_connection; }
            set { last_connection = value; }
        }

        public float TrustLevel
        {
            get { return trust_level; }
            set { trust_level = value; }
        }
    }
}