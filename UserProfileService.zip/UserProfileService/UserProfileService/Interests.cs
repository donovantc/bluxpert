﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace UserProfileService
{
    [DataContract]
    public class Interests
    {
        int interest_id;
        [DataMember]
        String interest_description;

        public Interests()
        {
            interest_id = 0;
            interest_description = "";
        }

        public int InterestID
        {
            get { return interest_id; }
            set { interest_id = value; }
        }

        public String InterestDescription
        {
            get { return interest_description; }
            set { interest_description = value; }
        }
    }
}