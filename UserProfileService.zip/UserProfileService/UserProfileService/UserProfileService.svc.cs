﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace UserProfileService
{
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
    public class UserProfileService : IUserProfileService
    {

        #region UserProfileService Members

        public void addUser(UserProfile user)
        {
            //add user to the database
            DataClasses1DataContext db = new DataClasses1DataContext();
            
            //insert the user into the table
            db.Users.InsertOnSubmit(new Users { UserName = user.Name, UserSurname = user.Surname, UserJobTitle = user.JobTitle, UserBTID = user.BTID, UserBetweenness = user.Betweenness,
                            UserTrust = user.TrustLevel});
            db.SubmitChanges();
        }

        public UserProfile getUserProfileByName(string name, string surname)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();

            //search for the user in the database
            var query = from u in db.Users
                        where (u.UserName.Equals(name) && u.UserSurname.Equals(surname))
                        select new { u.UserID, u.UserName, u.UserSurname, u.UserJobTitle, u.UserBTID, u.UserBetweenness, u.UserTrust };

            //temporary variables
            int count = 0;
            UserProfile tempUP;


            foreach (var q in query)
            {
                count++;
                if (count >= 1) break; //the user has already been found (more than one user exists, return the first one

                //create the user profile
                tempUP = new UserProfile { ID = q.UserID, Name = q.UserName, Surname = q.UserSurname, BTID = q.UserBTID, JobTitle = q.UserJobTitle };

                //get the users interests from the database
                

            }

        }

        public UserProfile getUserProfileByID(int userID)
        {
            throw new NotImplementedException();
        }

        public List<UserProfile> searchUser(string keyword)
        {
            throw new NotImplementedException();
        }

        public List<UserProfile> getAllUsers()
        {
            List<UserProfile> users_list = new List<UserProfile>();

            DataClasses1DataContext db = new DataClasses1DataContext();
            var query = from u in db.Users
                        select new { u.UserID, u.UserName, u.UserSurname, u.UserJobTitle, u.UserBTID };

            db.SubmitChanges();

            
            foreach (var q in query)
                users_list.Add(new UserProfile { ID = q.UserID, Name = q.UserName, Surname = q.UserSurname, JobTitle = q.UserJobTitle, BTID = q.UserBTID });
            
            return users_list;
        }
        #endregion
    }
}
