﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserProfileService
{
    public class DBConnectionManager
    {
        public DBConnectionManager()
        {
        }

        public void ConnectToDB()
        {
            
        }
    }
}