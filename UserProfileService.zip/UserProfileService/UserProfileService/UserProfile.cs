﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace UserProfileService
{
    [DataContract]
    public class UserProfile
    {
        [DataMember]
        int user_id;
        [DataMember]
        String name;
        [DataMember]
        String surname;
        [DataMember]
        String job_title;
        [DataMember]
        String bt_id;
        [DataMember]
        float betweenness;
        [DataMember]
        float trust_level;
        [DataMember]
        List<Interests> interests;
        [DataMember]
        List<Specialty> desired_specs;
        [DataMember]
        List<Friend> friends;

        public UserProfile()
        {
            user_id = 0;
            name = "";
            surname = "";
            job_title = "";
            bt_id = "";
            betweenness = 0;
            trust_level = 0;
            interests = new List<Interests>();
            desired_specs = new List<Specialty>();
        }

        public int ID
        {
            get { return user_id; }
            set { user_id = value; }
        }

        public String Name
        {
            get { return name; }
            set { name = value; }
        }

        public String Surname
        {
            get { return surname; }
            set { surname = value; }
        }

        public String JobTitle
        {
            get { return job_title; }
            set { job_title = value; }
        }

        public String BTID
        {
            get { return bt_id; }
            set { bt_id = value; }
        }

        public float Betweenness
        {
            get { return betweenness; }
        }

        public float TrustLevel
        {
            get { return trust_level; }
        }

        public List<Interests> Interests
        {
            get { return interests; }
            set { interests = value; }
        }

        public List<Specialty> DesiredSpecialties
        {
            get { return desired_specs; }
            set { desired_specs = value; }
        }

        public List<Friend> Friends
        {
            get { return friends; }
            set { friends = value; }
        }
    }
}