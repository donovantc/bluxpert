﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace UserProfileService
{
    [DataContract]
    public class Specialty
    {
        int spec_id;
        [DataMember]
        String spec_description;

        public Specialty()
        {
            spec_id = 0;
            spec_description = "";
        }

        public int SpecID
        {
            get { return spec_id; }
            set { spec_id = value; }
        }

        public String SpecDescription
        {
            get { return spec_description; }
            set { spec_description = value; }
        }
    }
}