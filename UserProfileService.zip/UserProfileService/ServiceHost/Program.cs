﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Host
{
    class Program
    {
        static void Main(string[] args)
        {
            //use the service
            using (ServiceHost host = new ServiceHost(typeof(UserProfileService.UserProfileService),
                new Uri("http://localhost:8080/UserProfileService")))
            {
                host.AddServiceEndpoint(typeof(UserProfileService.IUserProfileService),
                    new BasicHttpBinding(), "UserProfileService");

                //start the service
                host.Open();

                //display in console
                Console.WriteLine("UserProfileService has started.");
                Console.WriteLine("Press <ENTER> to terminate the service");
                Console.ReadLine();
            }

            

        }
    }
}
