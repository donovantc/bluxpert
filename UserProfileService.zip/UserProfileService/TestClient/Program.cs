﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace TestClient
{
    class Program
    {
        static void Main(string[] args)
        {
            TestClient.UserProfileServiceReference.UserProfileServiceClient client = new TestClient.UserProfileServiceReference.UserProfileServiceClient("BasicHttpBinding_IUserProfileService");
            
            //get all the users
            TestClient.UserProfileServiceReference.UserProfile[] users = client.getAllUsers();

            for (int i = 0; i < users.Length; i++)
            {
                Console.WriteLine(users[i].name + " " + users[i].surname);
            }

            Console.WriteLine("Presss <ENTER> to exit client");
            Console.ReadLine();

        }
    }
}
